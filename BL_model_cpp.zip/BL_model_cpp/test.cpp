#include "miniBL.h"
#include <Eigen/Dense>
using namespace Eigen;
int n = 5;
int main() {
	string UserParam = R"( {"mortagage_amt": 0,   
				"month_spend": 0,  
				"liquidity": 0, 
				"Pmt": 0, 
				"liability_asset": 0,
				"month_income": 0, 
				"asset_investable": 20000,   
				"remain_amount": 0, 
				"fixAsset": 0,   
				"lambda_i":3,
				"fluctuation":0.02,
				"interest_payment":0,
				"insurance_portion":0,
		   		"min_bounds": [0, 0, 0, 0, 0] ,
				"max_bounds" : [1, 1, 1, 1, 1] ,
				"w0" : [0.2, 0.2, 0.2, 0.2, 0.2] ,
				"ctrl_matrix" : [[1, 1, 0, 0, 0], [1, 1, 1, 0, 0], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1]],
				"upper_limits" : [[1,0.6,0,0,0],[0.2,0.4,0.6,0.2,0.4]],
				"lambda_mkt" : 1,
				"category_limits_coefficient" :[[0, 2000, 2000, 3000, 2000, 5000],[1000, 3000, 5000, 8000, 10000, 15000]],
				"Category_code":[1,2,3,4,5],
				"point_weightP" : [[1, 0, 0, 0, 0], [0, 1, 0, 0, 0], [0, 0, 1, 0, 0], [0, 0, 0, 1, 0], [0, 0, 0, 0, 1]],
				"confidence_LC" : [1.0, 0.6499263, 0.5139907, 0.5, 0.5479227] ,
				"pointQ" : [5.56e-05, 0.0001288, 0.0003267, 0.0001519, 0.0003896] ,
				"historicalOdds" : [1, 0.89, 0.62, 0.56, 0.71] ,
				"min_bound_coefficient" : [[100, 200, 200, 200, 200], [1, 1, -1, -1, -1], [2, 2, 7, 7, 7]],
				"max_bound_coefficient" : [[0.6385884801183425, 0.1596471200295856, -0.399117800073964, -0.15964712002958562, -0.31929424005917123],[-0.24263580453208972, 0.2893410488669776, 0.8766473778325561, 0.31065895113302244, 0.621317902266044]],
				"order_mat":[[2,3,4,5],[3,2,4,5]],
				"omiga_mkt":[0.2, 0.2, 0.0853, 0.1, 0.4147],
				"tau_percent":0.756,
				"sigema":[[0.200583863,-0.000423957,0.153010245,-0.002187152,1.62E-02],[-0.000423957, 0.000173017, -0.000211607, 0.000215601, 1.64E-04], [0.153010245,-0.000211607,0.150204259,-0.002490884,1.50E-02],[-0.002187152, 0.000215601, -0.002490884, 0.0221677,1.69E-03],[0.016162731,0.000164071,0.014967302,0.001685378,2.61E-02]],
				"asset_investable_matrix":[[1,1,1,1,1],[1,2,2,3,4],[2,2,3,2,2],[2,3,3,4,4],[2,3,4,4,5],[2,3,5,5,5]]
})";

	string param2 = R"({"min_bounds": [0.5, 0.5],
                "max_bounds": [0.8, 0.8],
                "lambda_mkt": 1,
                "point_weightP": [[0.003820205009707027, 0], [0, 0.15]],
                "confidence_LC": [1, 0.05],
                "pointQ": [0.003820205009707027, 0.15],
                "tau_percent": 0.2, "w0": [0.5, 0.5],
                "sigema": [[0.040057916542470116, -0.00181899049837842], [-0.00181899049837842, 0.04003501610020557]],
                "omiga_mkt": [0.4999285191527615, 0.5000714808472385],
                "ctrl_matrix":  [[1, 1, 1, 1,1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1]],
                "upper_limits": [[1, 0.6], [0.2, 0.4]],
                "category_limits_coefficient": [[0, 2000, 2000, 3000, 2000, 5000], [1000, 3000, 5000, 8000, 10000, 15000]],
                "min_bound_coefficient": [[100, 200], [1, -1], [2, 7]],
                "order_mat": [[2, 3, 4, 5], [3, 2, 4, 5]],
                "asset_investable_matrix": [[1, 1, 1, 1, 1], [1, 2, 2, 3, 4], [2, 2, 3, 2, 2], [2, 3, 3, 4, 4], [2, 3, 4, 4, 5], [2, 3, 5, 5, 5]],
                "asset_bounds_max":[1,1],
				"asset_bounds_min":[0,0],
				"mortagage_amt": 0,
				"Category_code":[2,3],
                "month_spend": 0,
                "liquidity": 0,
                "Pmt": 0,
                "liability_asset": 0,
                "month_income": 0,
                "asset_investable": 20000,
                "remain_amount": 0,
                "fixAsset": 0,
                "lambda_i": 3,
                "fluctuation": 0.3,
                "interest_payment": 0,
                "insurance_portion": 0})";
	string param3 = R"({"min_bounds": [0.5, 0.5],
				 "max_bounds": [0.8, 0.8],
				 "asset_bounds_max": [1, 1],
				 "asset_bounds_min": [0, 0],
				 "lambda_mkt": 1,
				 "point_weightP": [[0.003820205009707027, 0], [0, 0.15]],
				 "confidence_LC": [1, 0.05],
				 "pointQ": [0.003820205009707027, 0.15],
				 "tau_percent": 0.2,
				 "w0": [0.5, 0.5],
				 "sigema": [[0.040057916542470116, -0.00181899049837842], [-0.00181899049837842, 0.04003501610020557]],
				 "omiga_mkt": [0.4999285191527615, 0.5000714808472385],
				 "ctrl_matrix": [[1, 1, 1, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1]],
				 "upper_limits": [[1, 0.6], [0.2, 0.4]],
				 "category_limits_coefficient": [[0, 2000, 2000, 3000, 2000, 5000], [1000, 3000, 5000, 8000, 10000, 15000]],
				 "Category_code": [4, 4],
				 "min_bound_coefficient": [[100, 200], [1, -1], [2, 7]],
				 "order_mat": [[2, 3, 4, 5], [3, 2, 4, 5]],
				 "asset_investable_matrix": [[1, 1, 1, 1, 1], [1, 2, 2, 3, 4], [2, 2, 3, 2, 2], [2, 3, 3, 4, 4], [2, 3, 4, 4, 5], [2, 3, 5, 5, 5]],
				 "mortagage_amt": 0,
				 "month_spend": 0,
				 "liquidity": 0,
				 "Pmt": 0,
				 "liability_asset": 0,
				 "month_income": 0,
				 "asset_investable": 20000,
				 "remain_amount": 0,
				 "fixAsset": 0,
				 "lambda_i": 3,
				 "fluctuation": 0.3,
				 "interest_payment": 0,
				 "insurance_portion": 0})";

	string Param4 = R"({"min_bounds": [0.5, 0.5],
				"max_bounds": [0.8, 0.8],
				"asset_bounds_max": [1, 1],
				"asset_bounds_min": [0, 0],
 "lambda_mkt": 1,
 "point_weightP": [[0.003820205009707027, 0], [0, 0.15]],
 "confidence_LC": [1, 0.05],
 "pointQ": [0.003820205009707027, 0.15],
 "tau_percent": 0.2, "w0": [0.5, 0.5],
 "Category_code": [2, 2],
 "sigema": [[0.040057916542470116, -0.00181899049837842],
 [-0.00181899049837842, 0.04003501610020557]], "omiga_mkt": [0.4999285191527615, 0.5000714808472385], "ctrl_matrix": [[1, 1, 1, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1]], "upper_limits": [[1, 0.6], [0.2, 0.4]], "category_limits_coefficient": [[0, 2000, 2000, 3000, 2000, 5000], [1000, 3000, 5000, 8000, 10000, 15000]], "min_bound_coefficient": [[100, 200], [1, -1], [2, 7]], "order_mat": [[2, 3, 4, 5], [3, 2, 4, 5]], "asset_investable_matrix": [[1, 1, 1, 1, 1], [1, 2, 2, 3, 4], [2, 2, 3, 2, 2], [2, 3, 3, 4, 4], [2, 3, 4, 4, 5], [2, 3, 5, 5, 5]], "mortagage_amt": 0, "month_spend": 0, "liquidity": 0, "Pmt": 0, "liability_asset": 0, "month_income": 0, "asset_investable": 20000, "remain_amount": 0, "fixAsset": 0, "lambda_i": 3, "fluctuation": 0.3, "interest_payment": 0, "insurance_portion": 0})";
	//{
	//	MatrixXd point_weightP_temp(n, n);
	//	MatrixXi ctrl_matrix_temp(5, 5);
	//	VectorXd pointQ_temp(n);
	//	VectorXd confidence_LC_temp(n);
	//	VectorXd w0_temp(n);
	//	VectorXd omiga_mkt_temp(n);
	//	VectorXi Category_code_temp(n);
	//	MatrixXd sigema_temp(n, n);

	//	MatrixXi order_mat_temp(2, 4);
	//	MatrixXd min_bound_coefficient_temp(3, n);
	//	MatrixXd upper_limits_temp(2, n);
	//	MatrixXd category_limits_coefficient_temp(2, 6);
	//	point_weightP_temp << 1, 0, 0, 0, 0,
	//		0, 1, 0, 0, 0,
	//		0, 0, 1, 0, 0,
	//		0, 0, 0, 1, 0,
	//		0, 0, 0, 0, 1;

	//	pointQ_temp << 5.56e-05, 0.0001288, 0.0003267, 0.0001519, 0.0003896;
	//	confidence_LC_temp << 1.0, 0.6499263, 0.5139907, 0.5, 0.5479227;

	//	w0_temp << 0.2, 0.2, 0.2, 0.2, 0.2;
	//	omiga_mkt_temp << 0.2, 0.2, 0.0853, 0.1, 0.4147;
	//	Category_code_temp << 1, 2, 3, 4, 5;
	//	sigema_temp << 0.000795968, -1.68e-06, 0.000607184, -8.68e-06, 6.41e-05,
	//		-1.68e-06, 6.87e-07, -8.40e-07, 8.56e-07, 6.51e-07,
	//		0.000607184, -8.40e-07, 0.000596049, -9.88e-06, 5.94e-05,
	//		-8.68e-06, 8.56e-07, -9.88e-06, 8.80e-05, 6.69e-06,
	//		6.41e-05, 6.51e-07, 5.94e-05, 6.69e-06, 0.0001034;
	//	min_bound_coefficient_temp << 100, 200, 200, 200, 200,
	//		1, 1, -1, -1, -1,
	//		2, 2, 7, 7, 7;
	//	upper_limits_temp << 1, 0.6, 0, 0, 0,
	//		0.2, 0.4, 0.6, 0.2, 0.4;
	//	order_mat_temp << 2, 3, 4, 5,
	//		3, 2, 4, 5;
	//	ctrl_matrix_temp << 1, 1, 1, 1, 1,
	//		1, 1, 1, 1, 1,
	//		1, 1, 1, 1, 1,
	//		1, 1, 1, 1, 1,
	//		1, 1, 1, 1, 1;
	//	category_limits_coefficient_temp << 0, 2000, 2000, 3000, 2000, 5000,
	//		1000, 3000, 5000, 8000, 10000, 15000;
	//	BlackLitterman BL(5, 1, 0, 0, 0, 0, 0, 20000, 0, 0, 0, 3, 0, 0, 0.02, 0, point_weightP_temp, pointQ_temp, confidence_LC_temp,
	//		1, w0_temp, omiga_mkt_temp, Category_code_temp, 0.756, sigema_temp, ctrl_matrix_temp, min_bound_coefficient_temp, upper_limits_temp,
	//		category_limits_coefficient_temp, order_mat_temp);
	//	BL.Optimize();

	//	BlackLitterman BL2(UserParam, point_weightP_temp, pointQ_temp, confidence_LC_temp,
	//		1, w0_temp, omiga_mkt_temp, Category_code_temp, 0.756, sigema_temp, ctrl_matrix_temp, min_bound_coefficient_temp, upper_limits_temp,
	//		category_limits_coefficient_temp, order_mat_temp);
	//	BL2.Optimize();
	//	/*point_weightP = point_weightP_temp;
	//	pointQ = pointQ_temp;
	//	confidence_LC = confidence_LC_temp;
	//	w0 = w0_temp;
	//	omiga_mkt = omiga_mkt_temp;
	//	Category_code = Category_code_temp;
	//	sigema = sigema_temp * 252;
	//	ctrl_matrix = ctrl_matrix_temp;
	//	order_mat = order_mat_temp;
	//	min_bound_coefficient = min_bound_coefficient_temp;
	//	max_bound_coefficient = max_bound_coefficient_temp;
	//	category_limits_coefficient = category_limits_coefficient_temp;*/
	//}
	BlackLitterman BL3(Param4);
	BL3.Optimize();
}