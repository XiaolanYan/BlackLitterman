#ifndef BLerror_h
#define BLerror_h
#include <iostream>

class BLerror {


};

class InputError :public BLerror {
};

class JsonInputError :public InputError {
public:
	JsonInputError() { std::cout << "\nJson����ʧ�ܣ�" << std::endl; };
	~JsonInputError() {};
};

class LambdaInputError :public InputError {
public:
	LambdaInputError() { std::cout << "\n����ϵ�����볬����Χ" << std::endl; };
	~LambdaInputError() {};
};

class OptMethodInputError :public BLerror {
public:
	OptMethodInputError() { std::cout << "\n�Ż�ģ���������" << std::endl; };
	~OptMethodInputError() {};
};

class OptOutputError : public BLerror {
public:
	OptOutputError() {};
	~OptOutputError() {};
};

class BoxConstraintsCannotBeMeet : public OptOutputError {
public:
	BoxConstraintsCannotBeMeet() { std::cout << "\nBox Constraints could not be meet" << std::endl; };
	~BoxConstraintsCannotBeMeet() {};
};

class LinearConstraintsCannotBeMeet : public OptOutputError {
public:
	LinearConstraintsCannotBeMeet() { std::cout << "\nLinear Constraints could not be meet" << std::endl; };
	~LinearConstraintsCannotBeMeet() {};
};
class NonlinearConstraintsCannotBeMeet : public OptOutputError {
public:
	NonlinearConstraintsCannotBeMeet() { std::cout << "\nNonlinear Constraints could not be meet" << std::endl; };
	~NonlinearConstraintsCannotBeMeet() {};
};

 

#endif