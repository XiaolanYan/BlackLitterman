#include <iostream>
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include <Eigen/dense>
#include <Eigen/LU>

#include "npeigen.h"
#include "miniBL.h"

#include "include/json/json.h"

using namespace std;
using namespace Eigen;

namespace py = pybind11;

MatrixXd convert_np_mat_double(py::array_t<double>& input)
{
    // ��ȡinput1����Ϣ
    py::buffer_info buf1 = input.request();
    // ���ά��
    if (buf1.ndim != 2)
    {
        cout << buf1.shape[0] << endl;
        throw std::runtime_error("matrix dims must be 2!");
    }
    int n_rows = buf1.shape[0], n_cols = buf1.shape[1];

    //ָ����ʶ�д numpy.ndarray
    double* ptr1 = (double*)buf1.ptr;
    // input data ��ֵ������
    MatrixXd data(n_rows, n_cols);
    for (int i = 0; i < n_rows; i++)
    {
        for (int j = 0; j < n_cols; j++)
            data(i, j) = ptr1[i * buf1.shape[1] + j];
    }

    return data;
}

MatrixXi convert_np_mat_int(py::array_t<int>& input)
//void LLE_Run(MatrixXd data, int k, int m = 2)
{

    // ��ȡinput1, input2����Ϣ
    py::buffer_info buf1 = input.request();
    // ���ά��
    if (buf1.ndim != 2)
    {
        throw std::runtime_error("integer matrix dims must be 2!");
    }
    int n_rows = buf1.shape[0], n_cols = buf1.shape[1];

    //ָ����ʶ�д numpy.ndarray
    int* ptr1 = (int*)buf1.ptr;


    // input data ��ֵ������
    MatrixXi data(n_rows, n_cols);
    for (int i = 0; i < n_rows; i++)
    {
        for (int j = 0; j < n_cols; j++)
            data(i, j) = ptr1[i * buf1.shape[1] + j];
    }

    return data;
}
VectorXd convert_np_vec_double(py::array_t<double>& input)
{
    // ��ȡinput1, input2����Ϣ
    py::buffer_info buf1 = input.request();
    // ���ά��
    if (buf1.ndim != 1)
    {
        throw std::runtime_error("double vector dims must be 1!");
    }
    int n_rows = buf1.shape[0];

    //ָ����ʶ�д numpy.ndarray
    double* ptr1 = (double*)buf1.ptr;

    // input data ��ֵ������
    VectorXd data(n_rows);
    for (int i = 0; i < n_rows; i++)
    {
        data(i) = ptr1[i];
    }

    return data;
}

VectorXi convert_np_vec_int(py::array_t<int>& input)
//void LLE_Run(MatrixXd data, int k, int m = 2)
{
    clock_t start_time, end_time, time1, time2;
    start_time = clock();

    // ��ȡinput1, input2����Ϣ
    py::buffer_info buf1 = input.request();
    // ���ά��
    if (buf1.ndim != 1)
    {
        throw std::runtime_error("integer vector dims must be 1!");
    }
    int n_rows = buf1.shape[0];

    //ָ����ʶ�д numpy.ndarray
    int* ptr1 = (int*)buf1.ptr;


    // input data ��ֵ������
    VectorXi data(n_rows);
    for (int i = 0; i < n_rows; i++)
    {
        data(i) = ptr1[i];
    }

    return data;
}

double is_connection() {
    return 1;
}

py::array_t<double> allocation(string Json) {
    BlackLitterman BL(Json);
    VectorXd result_vec = BL.Optimize();
    auto result = py::array_t<double>(result_vec.size());
    py::buffer_info buf1 = result.request();
    double* ptr = (double*)buf1.ptr;
    for (size_t idx = 0;idx < buf1.shape[0];idx++) {
        ptr[idx] = result_vec[idx];
    }
    return result;
}


PYBIND11_MODULE(BL_model_cpp, m) {
	m.doc() = "BL model";
    m.def("allocation", &allocation);
    m.def("is_connection", &is_connection);

}

