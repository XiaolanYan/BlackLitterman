#ifndef json_read_array_h
#define json_read_array_h

#include <Eigen/dense>
#include "json/json.h"
#include <iostream>

using namespace Eigen;
using namespace std;
VectorXd retrieve_json_vector_double(Json::Value root, string key);

VectorXi retrieve_json_vector_int(Json::Value root, string key);

MatrixXd retrieve_json_matrix_double(Json::Value root, string key);
MatrixXi retrieve_json_matrix_int(Json::Value root, string key);
#endif
