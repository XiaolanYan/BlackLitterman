#include "json/json.h"
#include <iostream>
#include <Eigen/dense>
#include "json_read_array.h"
/**
 * \brief Parse a raw string into Value object using the CharReaderBuilder
 * class, or the legacy Reader class.
 * Example Usage:
 * $g++ readFromString.cpp -ljsoncpp -std=c++11 -o readFromString
 * $./readFromString
 * colin
 * 20
 */
using namespace Eigen;
using namespace std;
//

int main() {
    //{
    //    //const std::string rawJson = R"({"Age": 20, "Name": "colin"})";
    //    const std::string BLJson = R"( {"mortagageAmt": 0,   
    //           "monthSpend": 0,  
    //           "liquidity": 0, 
    //           "Pmt": 0, 
    //           "liabilityAsset": 0,
    //           "monthIncome": 0, 
    //           "asset_investable": 20000,   
    //           "totalAssetAmt": 0, 
    //           "fixAsset": 0,   
    //           "lambda_i":6.5,  
    //           "fluctuation": "default"})";
    //    // const auto rawJsonLength = static_cast<int>(rawJson.length());
    //    const auto BLJsonLength = static_cast<int>(BLJson.length());
    //    std::cout << BLJsonLength << std::endl;
    //    constexpr bool shouldUseOldWay = false;
    //    JSONCPP_STRING err;
    //    Json::Value root;
    //    Json::CharReaderBuilder builder;
    //    const std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
    //    if (!reader->parse(BLJson.c_str(), BLJson.c_str() + BLJsonLength, &root,
    //        &err)) {
    //        std::cout << "error" << std::endl;
    //        return EXIT_FAILURE;
    //    }
    //    const std::string name = root["fluctuation"].asString();
    //    const int age = root["Pmt"].asInt();
    //    std::cout << name << std::endl;
    //    std::cout << age << std::endl;
    //    return EXIT_SUCCESS;

    //}
    const std::string BLJson = R"( {
        "Name": "Morris",
            "Skills" : [[-1.3847,2E-08,3.2, -4.445],
[2,3,4,5]],
"confidence_LC":[1,2,3,4,5],
"sigma":[[0.200583863,-0.000423957,0.153010245,-0.002187152,1.62E-02],[-0.000423957, 0.000173017, -0.000211607, 0.000215601, 1.64E-04], [0.153010245,-0.000211607,0.150204259,-0.002490884,1.50E-02],[-0.002187152, 0.000215601, -0.002490884, 0.0221677,1.69E-03],[0.016162731,0.000164071,0.014967302,0.001685378,2.61E-02]]

    })";
    Json::Value root;
    Json::CharReaderBuilder builder;
    JSONCPP_STRING err;

    const auto BLJsonLength = static_cast<int>(BLJson.length());
    const std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
    if (!reader->parse(BLJson.c_str(), BLJson.c_str() + BLJsonLength, &root,
        &err)) {
        std::cout << "error" << std::endl;
        return EXIT_FAILURE;
    }
    
    return 0;

}
