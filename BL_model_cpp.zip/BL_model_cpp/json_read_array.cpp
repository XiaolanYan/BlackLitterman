#include "json_read_array.h"

VectorXd retrieve_json_vector_double(Json::Value root, string key) {
    int size = root[key].size();
    VectorXd return_vec;
    return_vec.resize(size);
    for (int i = 0; i < size; ++i) {
        return_vec[i] = root[key][i].asDouble();
    }
    return return_vec;

}

VectorXi retrieve_json_vector_int(Json::Value root, string key) {
    int size = root[key].size();
    VectorXi return_vec;
    return_vec.resize(size);
    for (int i = 0; i < size; ++i) {
        return_vec[i] = root[key][i].asInt();
    }
    return return_vec;

}


MatrixXd retrieve_json_matrix_double(Json::Value root, string key) {
    int rows = root[key].size();
    int cols = root[key][0].size();
    MatrixXd return_mat;
    return_mat.resize(rows, cols);
    for (int i = 0;i < rows;++i) {
        for (int j = 0; j < cols;++j) {
            return_mat(i, j) = root[key][i][j].asDouble();
        }
    }
    return return_mat;
}
MatrixXi retrieve_json_matrix_int(Json::Value root, string key) {
    int rows = root[key].size();
    int cols = root[key][0].size();
    MatrixXi return_mat;
    return_mat.resize(rows, cols);
    for (int i = 0;i < rows;++i) {
        for (int j = 0; j < cols;++j) {
            return_mat(i, j) = root[key][i][j].asInt();
        }
    }
    return return_mat;
}
