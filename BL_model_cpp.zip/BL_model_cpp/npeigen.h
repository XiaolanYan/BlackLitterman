#include <Eigen/Dense>
#include <pybind11/numpy.h>

Eigen::MatrixXd convert_np_mat_double(pybind11::array_t<double>& input);
Eigen::MatrixXi convert_np_mat_int(pybind11::array_t<int>& input);
Eigen::VectorXd convert_np_vec_double(pybind11::array_t<double>& input);
Eigen::VectorXi convert_np_vec_int(pybind11::array_t<int>& input);